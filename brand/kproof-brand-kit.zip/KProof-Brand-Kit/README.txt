KProof Brand Kit v1.1

Open brand/index.html in a browser.
Vector exports: brand/assets/
Design tokens: brand/tokens.json and css/tokens.css
Font and SIL OFL license: assets/fonts/
Usage notes: brand/README.txt
